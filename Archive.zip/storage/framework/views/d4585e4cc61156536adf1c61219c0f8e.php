
<div class="container mx-auto px-4 sm:px-6 lg:px-8">
   
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
        <h1 class="text-3xl font-bold text-white mb-4 sm:mb-0 text-center sm:text-left w-full sm:w-auto">Kelola Link Vote</h1>
        <button wire:click="create()" class="btn btn-primary px-4 py-2 rounded-lg w-full sm:w-auto">
            <i class="fas fa-plus mr-2"></i>Tambah Link Baru
        </button>
    </div>

    <!--[if BLOCK]><![endif]--><?php if($isFormModalOpen): ?>
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" x-data="{ open: <?php if ((object) ('isFormModalOpen') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('isFormModalOpen'->value()); ?>')<?php echo e('isFormModalOpen'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('isFormModalOpen'); ?>')<?php endif; ?> }" x-show="open" @keydown.escape.window="open = false" style="display: none;">
        <div class="glass-card rounded-xl shadow-lg w-full max-w-full md:max-w-2xl max-h-[90vh] flex flex-col overflow-hidden" @click.away="open = false">
            <form wire:submit.prevent="store" class="flex-1 flex flex-col">
                <div class="p-6">
                    <div class="flex justify-between items-center pb-4 border-b border-border-color">
                        <h3 class="text-xl md:text-2xl font-bold text-white"><?php echo e($voteId ? 'Edit' : 'Tambah'); ?> Link Vote</h3>
                        <button type="button" wire:click="closeModal()" class="text-gray-400 hover:text-white text-3xl leading-none">&times;</button>
                    </div>
                </div>
                <div class="p-6 flex-1 overflow-y-auto">
                    <div class="space-y-4">
                        <div>
                            <label for="name" class="block text-sm text-gray-300">Nama Situs</label>
                            <input type="text" id="name" wire:model.lazy="name" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div>
                            <label for="description" class="block text-sm text-gray-300">Deskripsi</label>
                            <input type="text" id="description" wire:model.lazy="description" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div>
                            <label for="hadiah" class="block text-sm text-gray-300">Hadiah</label>
                            <input type="text" id="hadiah" wire:model.lazy="hadiah" placeholder="Contoh: Uang, Poin Rank, Crate Key" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['hadiah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div>
                            <label for="url" class="block text-sm text-gray-300">URL</label>
                            <input type="url" id="url" wire:model.lazy="url" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
                <div class="px-6 py-4 bg-bg-secondary/50 border-t border-border-color text-right rounded-b-xl flex justify-end gap-2">
                    <button type="button" wire:click="closeModal()" class="btn btn-secondary px-4 py-2 rounded-lg">Batal</button>
                    <button type="submit" class="btn btn-primary px-4 py-2 rounded-lg">Simpan</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="glass-card rounded-xl mt-6 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-border-color">
                <thead class="bg-bg-secondary">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">No.</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Nama</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Deskripsi</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Hadiah</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">URL</th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-text-secondary uppercase tracking-wider">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-bg-primary divide-y divide-border-color">
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $votes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-800/40 transition">
                        <td class="px-6 py-4 text-sm text-gray-300"><?php echo e($loop->iteration); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-300"><?php echo e($vote->name); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-300"><?php echo e($vote->description); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-300"><?php echo e($vote->hadiah); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <a href="<?php echo e($vote->url); ?>" target="_blank" class="text-blue-400 hover:text-blue-300 font-medium text-sm truncate block max-w-xs hover:underline"><?php echo e($vote->url); ?></a>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button wire:click="edit(<?php echo e($vote->id); ?>)" class="text-blue-400 hover:text-blue-300">Edit</button>
                            <button wire:click="$dispatch('swal:confirm', { id: <?php echo e($vote->id); ?>, method: 'destroyVote' })" class="ml-4 text-red-500 hover:text-red-400">Hapus</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-gray-400">Tidak ada data link vote ditemukan.</td>
                    </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-4">
        <?php echo e($votes->links()); ?>

    </div>
</div>
<?php /**PATH /home/zayidx/Documents/WEBSERVERLYTHERIA/Web_Lyhteria/resources/views/livewire/admin/vote.blade.php ENDPATH**/ ?>