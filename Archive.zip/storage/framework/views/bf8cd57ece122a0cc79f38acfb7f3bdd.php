<div>
    <div class="container mx-auto px-4 sm:px-6 lg:px-8"> <!-- Added responsive padding -->
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6"> <!-- Adjusted for stacking on small screens -->
            <h1 class="text-3xl font-bold text-white mb-4 sm:mb-0 text-center sm:text-left w-full sm:w-auto">Manajemen Berita</h1>
            <div class="flex flex-col sm:flex-row gap-3 sm:gap-5 w-full sm:w-auto"> <!-- Adjusted for stacking buttons -->
                <button wire:click="create()" class="btn btn-primary px-4 py-2 rounded-lg w-full sm:w-auto">
                    <i class="fas fa-plus mr-2"></i>Tambah Berita
                </button>
                <button class="btn btn-primary px-4 py-2 rounded-lg w-full sm:w-auto">
                    <a href="<?php echo e(route('admin.categories')); ?>"><i class="fas fa-plus mr-2"></i>Tambah Kategori</a>
                </button>
            </div>
        </div>

        <!--[if BLOCK]><![endif]--><?php if($isFormModalOpen): ?>
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" x-data="{ open: <?php if ((object) ('isFormModalOpen') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('isFormModalOpen'->value()); ?>')<?php echo e('isFormModalOpen'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('isFormModalOpen'); ?>')<?php endif; ?> }" x-show="open" @keydown.escape.window="open = false" style="display: none;">
            <div class="glass-card rounded-xl shadow-lg w-full max-w-full md:max-w-4xl max-h-[90vh] flex flex-col overflow-y-scroll" @click.away="open = false"> <!-- Adjusted max-w for mobile -->
                <form wire:submit.prevent="store" class="flex flex-col flex-1">
                    <div class="p-6">
                        <div class="flex justify-between items-center pb-4 border-b border-border-color">
                            <h3 class="text-xl md:text-2xl font-bold text-white"><?php echo e($newsId ? 'Edit Berita' : 'Tambah Berita Baru'); ?></h3> <!-- Responsive text size -->
                            <button type="button" wire:click="$set('isFormModalOpen', false)" class="text-gray-400 hover:text-white text-3xl leading-none">&times;</button>
                        </div>
                    </div>
                    <div class="p-6 flex-1 overflow-y-auto">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div class="md:col-span-2 space-y-6">
                                <div>
                                    <label for="title" class="block text-sm font-medium text-text-secondary">Judul Berita</label>
                                    <input type="text" id="title" wire:model.lazy="title" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div wire:ignore>
                                    <label for="content" class="block text-sm font-medium text-text-secondary">Konten (Markdown)</label>
                                    <textarea id="content" class="hidden"></textarea>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="space-y-6">
                                <div>
                                    <label for="status" class="block text-sm font-medium text-text-secondary">Status</label>
                                    <select id="status" wire:model.lazy="status" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                                        <option value="draft">Draft</option>
                                        <option value="published">Published</option>
                                    </select>
                                </div>
                                <div>
                                    <label for="categoryId" class="block text-sm font-medium text-text-secondary">Kategori</label>
                                    <select id="categoryId" wire:model.lazy="categoryId" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                                        <option value="">Pilih Kategori</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['categoryId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div>
                                    <label for="ownerId" class="block text-sm font-medium text-text-secondary">Penulis</label>
                                    <select id="ownerId" wire:model.lazy="ownerId" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                                        <option value="">Pilih Penulis</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($owner->id); ?>"><?php echo e($owner->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['ownerId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div>
                                    <label for="imageUrl" class="block text-sm font-medium text-text-secondary">URL Gambar Header</label>
                                    <input type="url" id="imageUrl" wire:model.lazy="imageUrl" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['imageUrl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div>
                                    <label for="imageCaption" class="block text-sm font-medium text-text-secondary">Keterangan Gambar</label>
                                    <input type="text" id="imageCaption" wire:model.lazy="imageCaption" class="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md text-white px-3 py-2">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['imageCaption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="px-6 py-4 bg-bg-secondary/50 border-t border-border-color text-right rounded-b-xl flex justify-end gap-2"> <!-- Added flex and gap for buttons -->
                        <button type="button" wire:click="$set('isFormModalOpen', false)" class="btn btn-secondary px-4 py-2 rounded-lg">Batal</button>
                        <button type="submit" class="btn btn-primary px-4 py-2 rounded-lg">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="glass-card rounded-xl mt-6 overflow-hidden">
            <div class="overflow-x-auto"> <!-- Added for horizontal scrolling on small screens -->
                <table class="min-w-full divide-y divide-border-color">
                    <thead class="bg-bg-secondary">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Judul</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Penulis</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Tanggal</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-text-secondary uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-bg-primary divide-y divide-border-color">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-white"><?php echo e(\Illuminate\Support\Str::limit($item->title, 40)); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($item->status == 'published' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'); ?>">
                                    <?php echo e(ucfirst($item->status)); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-text-secondary"><?php echo e($item->owner->name); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-text-secondary"><?php echo e($item->created_at->format('d M Y')); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button wire:click="edit(<?php echo e($item->id); ?>)" class="text-teal-400 hover:text-teal-300">Edit</button>
                                <button wire:click="$dispatch('swal:confirm', { id: <?php echo e($item->id); ?>, method: 'destroy' })" class="ml-4 text-red-500 hover:text-red-400">Hapus</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center text-text-secondary">Belum ada berita yang ditambahkan.</td>
                        </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
        <div class="mt-4">
            <?php echo e($news->links()); ?>

        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('livewire:init', () => {
            let easyMDE = null;

            // Fungsi untuk menginisialisasi atau menghancurkan editor
            const setupEditor = (content) => {
                // Hancurkan instance lama jika ada
                if (easyMDE) {
                    easyMDE.toTextArea();
                    easyMDE = null;
                }

                // Inisialisasi instance baru
                const textarea = document.getElementById('content');
                if (textarea) {
                    easyMDE = new EasyMDE({
                        element: textarea,
                        initialValue: content,
                        spellChecker: false,
                        minHeight: '250px',
                        maxHeight: '400px',
                        // Anda bisa menambahkan atau mengurangi toolbar di sini
                        toolbar: ["bold", "italic", "heading", "|", "quote", "unordered-list", "ordered-list", "|", "link", "image", "|", "preview", "side-by-side", "fullscreen"],
                    });

                    // Update properti Livewire saat konten editor berubah
                    easyMDE.codemirror.on('change', () => {
                        window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('content', easyMDE.value());
                    });
                }
            };

            // Listener untuk event dari backend
            Livewire.on('initialize-editor', (event) => {
                // Beri sedikit jeda agar DOM modal sepenuhnya siap
                setTimeout(() => {
                    setupEditor(event.content);
                }, 50); 
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH /home/zayidx/Documents/WEBSERVERLYTHERIALIVEWIRE/ServerLytheria/resources/views/livewire/admin/news.blade.php ENDPATH**/ ?>