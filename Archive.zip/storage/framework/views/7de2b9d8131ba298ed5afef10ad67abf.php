<div class="py-24 bg-black/20">
    <div class="container mx-auto px-6">
        <header class="text-center mb-12">
            <h1 class="text-4xl md:text-5xl font-extrabold text-white">Berita & Pengumuman</h1>
            <p class="mt-2 text-lg text-gray-400">Ikuti perkembangan terbaru dari dunia <?php echo e($settings['server_name'] ?? 'Nilai Default'); ?>.</p>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="glass-card rounded-xl overflow-hidden flex flex-col group" wire:key="<?php echo e($item->id); ?>">
                    <a href="<?php echo e(route('news.detail', $item->slug)); ?>">
                        <img src="<?php echo e($item->image_url ?: 'https://placehold.co/600x400/161B22/c9d1d9?text=Berita'); ?>" alt="<?php echo e($item->title); ?>" class="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-300">
                    </a>
                    <div class="p-6 flex flex-col flex-1">
                        <p class="text-sm text-blue-400 font-semibold"><?php echo e($item->category->name); ?></p>
                        <h2 class="mt-2 text-xl font-bold text-white flex-1 truncate">
                            <a href="<?php echo e(route('news.detail', $item->slug)); ?>" class="hover:text-blue-300 transition" title="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></a>
                        </h2>
                        <p class="mt-3 text-gray-400 text-sm">
                            <?php echo e(\Illuminate\Support\Str::limit(strip_tags($item->content), 120)); ?>

                        </p>
                        <footer class="mt-4 pt-4 border-t border-gray-800 flex items-center justify-between">
                            <div class="text-xs text-gray-500">
                                oleh <?php echo e($item->owner->name); ?> <br>
                                <?php echo e($item->published_at->format('d F Y')); ?>

                            </div>
                            <a href="<?php echo e(route('news.detail', $item->slug)); ?>" class="text-sm font-semibold text-blue-400 hover:text-white">
                                Baca &rarr;
                            </a>
                        </footer>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="lg:col-span-3 text-center py-16">
                    <p class="text-gray-400">Belum ada berita yang dipublikasikan saat ini.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="mt-12">
            <?php echo e($news->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/zayidx/Documents/WEBSERVERLYTHERIALIVEWIRE/ServerLytheria/resources/views/livewire/news.blade.php ENDPATH**/ ?>